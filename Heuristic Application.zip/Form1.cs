﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Heuristic_Application.algo;

namespace Heuristic_Application
{
    public partial class Form1 : Form
    {
        List<Graphe> ouvert;
        Graphe Result;

      
        List<Graphe> res;
        int selected;

        public Form1()
        {
            InitializeComponent();
            int[,] res = new int[3,3];
            res[0, 0] = 1;
            res[0, 1] = 2;
            res[0, 2] = 3;

            res[1, 0] = 4;
            res[1, 1] = 5;
            res[1, 2] = 6;

            res[2, 0] = 7;
            res[2, 1] = 8;
            res[2, 2] = 0;

            Result = new Graphe(res);
        }

        private bool move(Button bt)
        {
            TableLayoutPanelCellPosition position = tableLayoutPanel1.GetCellPosition(bt);
                if(isCellFree(position.Row - 1, position.Column)){
                    tableLayoutPanel1.SetColumn(bt, position.Column);
                    tableLayoutPanel1.SetRow(bt, position.Row - 1);
                    return true;
                }
           

                if (isCellFree(position.Row + 1, position.Column))
                {
                    tableLayoutPanel1.SetColumn(bt, position.Column);
                    tableLayoutPanel1.SetRow(bt, position.Row + 1);
                    return true;
                }
           

                if (isCellFree(position.Row, position.Column -1))
                {
                    tableLayoutPanel1.SetColumn(bt, position.Column - 1);
                    tableLayoutPanel1.SetRow(bt, position.Row);
                    return true;
                }
          
                if (isCellFree(position.Row, position.Column + 1))
                {
                    tableLayoutPanel1.SetColumn(bt, position.Column + 1);
                    tableLayoutPanel1.SetRow(bt, position.Row);
                    return true;
                }
          
            return false;
        }

        /// <summary>
        /// Verify if a specifiend cell is unoccuped
        /// </summary>
        /// <param name="row">row of cell</param>
        /// <param name="column">column of cell</param>
        /// <returns></returns>
        private bool isCellFree(int row, int column)
        {          
            if (row > 2 || column > 2 || row == -1 || column == -1)
                return false;
            else
                return (tableLayoutPanel1.GetControlFromPosition(column, row) == null);
        }

        private void bt1_Click(object sender, EventArgs e)
        {
            move(bt1);
        }

        private void bt2_Click(object sender, EventArgs e)
        {
            move(bt2);
        }

        private void bt3_Click(object sender, EventArgs e)
        {
            move(bt3);
        }

        private void bt4_Click(object sender, EventArgs e)
        {
            move(bt4);
        }

        private void bt5_Click(object sender, EventArgs e)
        {
            move(bt5);
        }

        private void bt6_Click(object sender, EventArgs e)
        {
            move(bt6);
        }

        private void bt7_Click(object sender, EventArgs e)
        {
            move(bt7);
        }

        private void bt8_Click(object sender, EventArgs e)
        {
            move(bt8);
        }

        /// <summary>
        /// transform lavue en tablau deux dumensions
        /// </summary>
        /// <returns></returns>
        private int[,] getConfig()
        {
            int[,] response = new int[3,3];
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (tableLayoutPanel1.GetControlFromPosition(j, i) == null)
                        response[i,j] = 0;
                    else
                        response[i,j] = Convert.ToInt32(((Button)tableLayoutPanel1.GetControlFromPosition(j, i)).Text);
            return response;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == -1)
                MessageBox.Show("Veuillez choisir une heuristique", null, MessageBoxButtons.OK, MessageBoxIcon.Error);
            else
            {
                Graphe p = aStar.astar(new Taquin(new Graphe(getConfig())), comboBox1.SelectedIndex);

                res = new List<Graphe>();
                while (p != null)
                {
                    if (!Helper.check(p, res))
                    {
                        res.Add(p);
                    }
                    p = p.Parent;
                }
                res.Reverse();
                             
                selected = 0;

                lbl_coup.Text = (res.Count - 1).ToString();
                label3.Text = selected + " / " + (res.Count-1);
            }
        }

        private void findPath()
        {
            
        }

        /// <summary>
        /// Check if graph exist in list ouvert
        /// </summary>
        /// <param name="g">graphe a tester</param>
        /// <returns></returns>

        private bool check(Graphe g)
        {
            foreach (Graphe p in ouvert)
            {
                if (Helper.Compare(g, p))
                    return true;
            }
            return false;
        }

        private bool match_(Graphe g)
        {
            return g.Compare(Result);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Taquin t = new Taquin(new Graphe(getConfig()));
            List<Graphe> fils = t.getChild();

            Random k = new Random();

            Graphe selected = fils.ElementAt(k.Next(0, fils.Count));

            for(int i = 0; i<3; i++)
                for (int j = 0; j < 3; j++)
                {
                    if (tableLayoutPanel1.GetControlFromPosition(j, i) != null)
                    {
                        if (Convert.ToInt32(((Button)tableLayoutPanel1.GetControlFromPosition(j, i)).Text) != selected.Cfg[i, j])
                        {
                            move((Button)tableLayoutPanel1.GetControlFromPosition(j, i));
                        }
                    }
                }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (res != null && selected < res.Count-1)
            {
                selected++;
                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++)
                    {
                        if (tableLayoutPanel1.GetControlFromPosition(j, i) != null)
                        {
                            if (Convert.ToInt32(((Button)tableLayoutPanel1.GetControlFromPosition(j, i)).Text) != res.ElementAt(selected).Cfg[i, j])
                            {
                                move((Button)tableLayoutPanel1.GetControlFromPosition(j, i));
                            }
                        }
                    }
                label3.Text = selected + " / " + (res.Count - 1);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (selected > 0)
            {
                selected--;
                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++)
                    {
                        if (tableLayoutPanel1.GetControlFromPosition(j, i) != null)
                        {
                            if (Convert.ToInt32(((Button)tableLayoutPanel1.GetControlFromPosition(j, i)).Text) != res.ElementAt(selected).Cfg[i, j])
                            {
                                move((Button)tableLayoutPanel1.GetControlFromPosition(j, i));
                            }
                        }
                    }
                label3.Text = selected + " / " + (res.Count - 1);
            }
        }

        private void aProposAboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Made by ffaraniarijaona@gmail.com", "hello!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
