﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heuristic_Application.algo
{
    class Taquin
    {
        #region properties
            public Graphe FinalState { get; set; } // = Helper.getFinalState().getCopy();

            public Graphe InitialState { get; set; } //InitialState = null;

            public Graphe CurrentState { get; set; }// FinalState = null;

            public List<Graphe> child { get; set; } // = new List<Graphe>(); 
        #endregion

        public Taquin(Graphe InitialState)
        {
            this.InitialState = InitialState;
            this.CurrentState = InitialState.getCopy();
        }

        public List<Graphe> getChild(Graphe g=null)
        {
            g = (g==null)? this.CurrentState.getCopy():g.getCopy();
            List<Graphe> result = new List<Graphe>();
            bool found = false;

            #region Child from left move
                int[,] tmp = new int[3, 3];
                Helper.copyArray(g.Cfg, tmp);
                for (int i = 0; i < 3; i++)
                {
                    for (int j = 0; j < 3; j++)
                    {
                        if (tmp[i, j] == 0 && j > 0)
                        {
                            tmp[i, j] = g.Cfg[i, j - 1];
                            tmp[i, j - 1] = 0;
                            found = true;
                            break;
                        }
                    }
                    if (found)
                        break;
                }

                if (!Helper.check(new Graphe(tmp), result) && !Helper.Compare(new Graphe(tmp), new Graphe(g)))
                    result.Add(new Graphe(g, tmp));
            #endregion

            #region Child from Right move
            found = false;
            tmp = new int[3, 3];
            Helper.copyArray(g.Cfg, tmp);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (tmp[i, j] == 0 && j < 2)
                    {
                        tmp[i, j] = g.Cfg[i, j + 1];
                        tmp[i, j + 1] = 0;
                        found = true;
                        break;
                    }
                }
                if (found)
                    break;
            }
            if (!Helper.check(new Graphe(tmp), result) && !Helper.Compare(new Graphe(tmp), new Graphe(g)))
                result.Add(new Graphe(g, tmp));
            #endregion

            #region Child from Up move
            found = false;
            tmp = new int[3, 3];
            Helper.copyArray(g.Cfg, tmp);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (tmp[i, j] == 0 && i > 0)
                    {
                        tmp[i, j] = g.Cfg[i - 1, j];
                        tmp[i - 1, j] = 0;
                        found = true;
                        break;
                    }
                }
                if (found)
                    break;
            }

            if (!Helper.check(new Graphe(tmp), result) && !Helper.Compare(new Graphe(tmp), new Graphe(g)))
                result.Add(new Graphe(g, tmp));
            #endregion

            #region Child from Down move
            found = false;
            tmp = new int[3, 3];
            Helper.copyArray(g.Cfg, tmp);
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (tmp[i, j] == 0 && i < 2)
                    {
                        tmp[i, j] = g.Cfg[i + 1, j];
                        tmp[i + 1, j] = 0;
                        found = true;
                        break;
                    }
                }
                if (found)
                    break;
            }
            if (!Helper.check(new Graphe(tmp), result) && !Helper.Compare(new Graphe(tmp), new Graphe(g)))
                result.Add(new Graphe(g, tmp));
            #endregion

            return result;
        }
    }
}
