﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heuristic_Application.algo
{
    class Heuristic
    {
        #region HeuristicW
        public int w(Graphe currentState, Graphe FinalState)
        {
            int count = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    if (currentState.Cfg[i, j] != FinalState.Cfg[i, j])
                        count++;
            }
            return count;
        }

        public int bestWIndex(List<Graphe> graphe)
        {
            int best = 0;
            int nbPlaceErr = w(graphe.ElementAt(graphe.Count-1), Helper.getFinalState());

            for (int i = graphe.Count -2 ; i >= 0; i--)
            {
                if (w(graphe.ElementAt(i), Helper.getFinalState()) < nbPlaceErr)
                {
                    nbPlaceErr = w(graphe.ElementAt(i), Helper.getFinalState());
                    best = i;
                }
            }

            return best;
        } 
        #endregion

        #region HeuristicP
        public int p(Graphe currentState, Graphe FinalState)
        {
            int count = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    count += Math.Abs(Helper.getNumLine(currentState.Cfg[i, j], currentState) - (Helper.getNumLine(currentState.Cfg[i, j], FinalState)))
                        + Math.Abs(Helper.getNumCol(currentState.Cfg[i, j], currentState) - (Helper.getNumCol(currentState.Cfg[i, j], FinalState)));
                }
            }
            return count;
        }

        public int bestPIndex(List<Graphe> graphe)
        {
            int best = 0;
            int count = p(graphe.ElementAt(0), Helper.getFinalState());
            for (int i = 0; i < graphe.Count; i++)
            {
                if (p(graphe.ElementAt(i), Helper.getFinalState()) < count)
                {
                    count = p(graphe.ElementAt(i), Helper.getFinalState());
                    best = i;
                }
            }
            return best;
        } 
        #endregion

        #region Heuristic p3s
        public int p3s(Graphe currentState, Graphe FinalState)
        {
            int count = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (i != 1 && j != 1)
                    {
                        bool next = false;
                        if (i == 2 && j == 2)
                        {
                            next = (currentState.Cfg[i - 1, j] == FinalState.Cfg[i - 1, j]);
                        }
                        else
                        {
                            if (i < 2)
                                next = (currentState.Cfg[i + 1, j] == FinalState.Cfg[i + 1, j]);
                            else
                                next = (currentState.Cfg[i, j + 1] == FinalState.Cfg[i, j + 1]);
                        }
                        if (currentState.Cfg[i, j] == FinalState.Cfg[1, 1] || currentState.Cfg[i, j] == 0
                            || !next)
                        {
                            count += 2;
                        }
                    }
                }

            }
            if (currentState.Cfg[1, 1] == 0 || currentState.Cfg[1, 1] != FinalState.Cfg[1, 1])
            {
                count += 1;
            }
            return 3 * count + p(currentState, FinalState);
        }

        public int bestP3SIndex(List<Graphe> graphe)
        {
            int best = 0;
            int count = p3s(graphe.ElementAt(0), Helper.getFinalState());

            for (int i = 0; i < graphe.Count; i++)
            {
                if (p3s(graphe.ElementAt(i), Helper.getFinalState()) < count)
                {
                    count = p3s(graphe.ElementAt(i), Helper.getFinalState());
                    best = i;
                }
            }
            return best;
        } 
        #endregion

    }
}
