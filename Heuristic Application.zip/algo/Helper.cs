﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heuristic_Application.algo
{
    static class Helper
    {
        public static void showarr(int[,] array)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    Console.Write(array[i, j] + "\t");
                Console.WriteLine();
            }
        }

        public static void copyArray(int[,] from, int[,] to)
        {
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    to[i, j] = from[i, j];
        }

        public static bool Compare(Graphe a, Graphe b)
        {
            int[,] cfga = a.Cfg;
            int[,] cfgb = b.Cfg;

            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    if (cfga[i, j] != cfgb[i, j])
                        return false;

            return true;
        }

        public static bool check(Graphe g, List<Graphe> list)
        {
            foreach (Graphe p in list)
            {
                if (Helper.Compare(g, p))
                    return true;
            }
            return false;
        }

        public static Graphe getFinalState()
        {
            int[,] a = new int[3, 3];
            a[0, 0] = 1;
            a[0, 1] = 2;
            a[0, 2] = 3;

            a[1, 0] = 4;
            a[1, 1] = 5;
            a[1, 2] = 6;

            a[2, 0] = 7;
            a[2, 1] = 8;
            a[2, 2] = 0;

            return new Graphe(a);
        }

        /// <summary>
        /// maka ny numero an ligne ana chifffre c omena
        /// </summary>
        /// <param name="c"></param>
        /// <param name="dans"></param>
        /// <returns></returns>
        public static int getNumLine(int c, Graphe dans)
        {
            for(int i=0; i< 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (dans.Cfg[i, j] == c)
                        return i;
                }

            }
            return -1;
        }

        public static int getNumCol(int c, Graphe dans)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (dans.Cfg[i, j] == c)
                        return j;
                }

            }
            return -1;
        }

        public static List<Graphe> copyList(List<Graphe> listToBeCopied)
        {
            List<Graphe> tmp = new List<Graphe>();
            foreach (Graphe g in listToBeCopied)
            {
                tmp.Add(g.getCopy());
            }
            return tmp;
        }

        public static int getIndexElem(Graphe g, List<Graphe> l)
        {
            for (int i = 0; i < l.Count; i++)
            {
                if(Compare(g, l.ElementAt(i)))
                    return i;
            }
            return -1;
        }
    }
}
