﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heuristic_Application.algo
{
    class aStar
    {
        public static Graphe astar(Taquin t, int heuristic_choice=0)
        {
            //int heuristic_choice = 0;
            List<Graphe> closed = new List<Graphe>();
            List<Graphe> opened = new List<Graphe>();

            Heuristic heur = new Heuristic();

            opened.Add(t.InitialState);
           // closed.Add(t.InitialState);
            int nbIteration = 0;

            while(!Helper.Compare(t.CurrentState, Helper.getFinalState()) && opened.Count>0)
            {
                if (!Helper.check(t.CurrentState, closed))
                    closed.Add(t.CurrentState);

                    List<Graphe> child = Helper.copyList(t.getChild(t.CurrentState));

                for (int i = 0; i < child.Count; i++)
                {
                    Console.WriteLine();
                    if(!Helper.check(child.ElementAt(i), closed))
                    {
                        if (!Helper.check(child.ElementAt(i), opened))
                        {
                            opened.Add(child.ElementAt(i));
                        }
                       
                    }
                }

                int index = 0;

                switch (heuristic_choice)
                {
                    case 0:
                        index = heur.bestWIndex(opened);
                        break;
                    case 1:
                        index = heur.bestPIndex(opened);
                        break;
                    case 2:
                        index = heur.bestP3SIndex(opened);
                        break;

                }
                t.CurrentState = opened.ElementAt(index);
                opened.RemoveAt(index);
                nbIteration++;
            }

            return t.CurrentState.getCopy();
        }
    }
}
