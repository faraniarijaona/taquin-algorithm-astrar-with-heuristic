﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heuristic_Application.algo
{
    class Graphe
    {
        #region Properties
            public Graphe Parent { get; set; }

            public int[,] Cfg { get; set; }

            public List<Graphe> Child { get; set; }
        #endregion

        #region Constructor 

            public Graphe(int[,] cfg)
            {
                this.Cfg = cfg;                
                //Child = this.getChild();
            }

            public Graphe(Graphe parent)
            {
                this.Parent = parent;
                this.Cfg = new int[3, 3];
                Helper.copyArray(parent.Cfg, this.Cfg);                
                //Child = this.getChild();
            }

            public Graphe(Graphe parent, int[,] cfg)
            {
                this.Parent = parent;
                this.Cfg = new int[3,3];
                Helper.copyArray(cfg, this.Cfg);
                //Child = this.getChild();
            }

        #endregion

        #region Methods
            public Graphe getCopy()
            {
                return new Graphe(this);
            }
            public bool Compare(Graphe a)
            {
                int[,] cfga = this.Cfg;
                int[,] cfgb = a.Cfg;

                for (int i = 0; i < 3; i++)
                    for (int j = 0; j < 3; j++)
                        if (cfga[i, j] != cfgb[i, j])
                            return false;

                return true;
            }
        #endregion


    }
}
