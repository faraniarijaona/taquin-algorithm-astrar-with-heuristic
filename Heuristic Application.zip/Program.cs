﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using Heuristic_Application.algo;

namespace Heuristic_Application
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
           // int[,] a = new int[3, 3];
           // a[0, 0] = 1;
           // a[0, 1] = 5;
           // a[0, 2] = 3;

           // a[1, 0] = 4;
           // a[1, 1] = 0;
           // a[1, 2] = 6;

           // a[2, 0] = 7;
           // a[2, 1] = 8;
           // a[2, 2] = 2;

           // //Console.WriteLine();

           // //Graphe g = new Graphe(a);

           // //List<Graphe> l = g.getChild();

           // //foreach (Graphe p in l)
           // //{
           // //    Helper.showarr(p.Cfg);
           // //    Console.WriteLine();
           // //}
             
           //// Console.WriteLine("line "+ new Heuristic().p(new Graphe(a), Helper.getFinalState()));

           // Graphe p = aStar.astar(new Taquin(new Graphe(a))).getCopy();
           // List<Graphe> res = new List<Graphe>();

           // while (p != null)
           // {
           //    // if (!Helper.check(p, res))
           //         res.Add(p);
           //     // Helper.showarr(p.Cfg);
           //     p = p.Parent;
           //     // Console.WriteLine();
           // }

           // for (int i = res.Count; i > 0; i--)
           // {
           //     Helper.showarr(res.ElementAt(i - 1).Cfg);
           //     Console.WriteLine();
           // }
        }
       
    }
}
